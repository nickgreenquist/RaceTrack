Nick Greenquist
3D World Readme

Summary:
I decided to create a race car track for my 3D world. My two autonomous actors are my race cars and my pit crew. The race cars react
with the environment by following a path(the race track). The pit crew responds only to the racecars. If a racecar enters the pit
stop, the pit crew seeks the car until it is "fixed up." The cars respond to each other as well as the path. They seperate from each
other. They also pass one another. They do this through the use of two ray casts. The first ray cast extends far out, and if it hits
another car, the car gets a speed boost. The other ray cast looks closer. If that ray hits another car, the car will switch lanes.
Together with the speed boost, this results in other cars passing each other. Most of the models I used in this project were from
free dowloads from the Unity asset store. The packages I used are named below. 

Instructions:
Hit the spacebar to start the race!
Hit F1-F9 and A,S,D,F,G keys to cycle through the 15 cars. 
Hit the Up-Arrow to make the camera follow a random car
Hit the Return key to center the camera over the pit stop

Credit:
1. Stock Car
2. Car Tutorial (some assets and sound)
3. Terrain Assets

